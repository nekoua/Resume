A Pen created at CodePen.io. You can find this one at http://codepen.io/sean-su/pen/YXyMzO.

 主要應用了 Google Material Design 的漣漪效果 (Ripple effect) 。
漣漪效果透過顏色的渲染跟陰影的變化，讓按鈕本身感覺上有重量。
歡迎提出使用上的建議。